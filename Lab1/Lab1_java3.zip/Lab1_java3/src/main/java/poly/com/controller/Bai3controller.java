package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Bai 3")
public class Bai3controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	  String url = req.getRequestURL().toString();
	    String uri = req.getRequestURI();
	    String query = req.getQueryString();
	    String servletPath = req.getServletPath();
	    String contextPath = req.getContextPath();
	    String pathInfo = req.getPathInfo();
	    String method = req.getMethod();

	    resp.getWriter().println("<h3>Thông tin URL</h3>");
	    resp.getWriter().println("1. URL: " + url + "<br>");
	    resp.getWriter().println("2. URI: " + uri + "<br>");
	    resp.getWriter().println("3. QueryString: " + query + "<br>");
	    resp.getWriter().println("4. ServletPath: " + servletPath + "<br>");
	    resp.getWriter().println("5. ContextPath: " + contextPath + "<br>");
	    resp.getWriter().println("6. PathInfo: " + pathInfo + "<br>");
	    resp.getWriter().println("7. Method: " + method + "<br>");
}
}
